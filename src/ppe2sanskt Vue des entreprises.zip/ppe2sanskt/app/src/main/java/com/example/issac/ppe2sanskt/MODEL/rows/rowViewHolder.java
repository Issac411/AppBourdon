package com.example.issac.ppe2sanskt.MODEL.rows;

import android.widget.ImageView;
import android.widget.TextView;

public class rowViewHolder {
    public TextView name;
    public TextView desc;
    public ImageView color;
}
