package com.example.issac.ppe2sanskt.IHM;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.example.issac.ppe2sanskt.R;

public class main_options extends AppCompatActivity {
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_options);
    }
}
